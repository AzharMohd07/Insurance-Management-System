package com.example.service;

public interface EmailService {


    public void sendPolicyNotification(String to, String subject, String text);
}
