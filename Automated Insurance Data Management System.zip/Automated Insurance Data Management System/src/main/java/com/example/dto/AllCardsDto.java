package com.example.dto;

public class AllCardsDto {

    private String cardName;

    public String getCardName() {
        return cardName;
    }

    public AllCardsDto(String cardName, String cardSize, String cardDescription) {
        this.cardName = cardName;
        this.cardSize = cardSize;
        this.cardDescription = cardDescription;
    }

    public void setCardName(String cardName) {
        this.cardName = cardName;
    }

    public String getCardSize() {
        return cardSize;
    }

    public void setCardSize(String cardSize) {
        this.cardSize = cardSize;
    }

    public String getCardDescription() {
        return cardDescription;
    }

    public void setCardDescription(String cardDescription) {
        this.cardDescription = cardDescription;
    }

    private String cardSize;

    private String cardDescription;
}
