package com.example.controller;

import com.example.entity.Policy;
import com.example.service.PolicyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DashboardController {

    @Autowired
    private PolicyService policyService;

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        model.addAttribute("totalPolicies", policyService.getAllPolicies().size());
        model.addAttribute("totalPremium", policyService.getAllPolicies().stream().mapToDouble(Policy::getPremium).sum());
        return "dashboard";
    }}