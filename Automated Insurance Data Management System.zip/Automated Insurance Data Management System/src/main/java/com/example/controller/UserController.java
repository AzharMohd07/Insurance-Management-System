package com.example.controller;

import com.example.dto.UserDto;
import com.example.entity.User;
import com.example.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "http://localhost:3000")
public class UserController {
    @Autowired
    private UserRepository userRepository;

    @PostMapping("/signup")
    public ResponseEntity<String> signup(@RequestBody User user) {
        // Validate username and password
        if (!isValidUsername(user.getUsername())) {
            return ResponseEntity.badRequest().body("Invalid username");
        }

        if (!isValidPassword(user.getPassword())) {
            return ResponseEntity.badRequest().body("Invalid password");
        }
        try {
            userRepository.save(user);
            return ResponseEntity.ok("User registered successfully");
        } catch (Exception e) {
            // Handle unique constraint violation (duplicate username)
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Username already exists");
        }
    }

    private boolean isValidUsername(String username) {
        // Implement your username validation logic (e.g., length constraints)
        return username.length() >= 5;
    }

    private boolean isValidPassword(String password) {
        // Implement your password validation logic (e.g., length and numeric requirements)
        return password.length() >= 5 && countNumbers(password) > 2;
    }

    private int countNumbers(String input) {
        // Count the number of numeric characters in the input string
        int count = 0;
        for (char c : input.toCharArray()) {
            if (Character.isDigit(c)) {
                count++;
            }
        }
        return count;
    }

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody UserDto user) {
        try {
            List<User> users = userRepository.findByUsername(user.getUsername());

            if (users.isEmpty()) {
                throw new IllegalArgumentException("Invalid username");
            }

            User storedUser = users.get(0);

            if (!Objects.equals(storedUser.getPassword(), user.getPassword())) {
                throw new IllegalArgumentException("Invalid username or password");
            }

            return ResponseEntity.ok("Login successful");
        } catch (IllegalArgumentException e) {
            // Failed login, return error message with a bad request status
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

}
