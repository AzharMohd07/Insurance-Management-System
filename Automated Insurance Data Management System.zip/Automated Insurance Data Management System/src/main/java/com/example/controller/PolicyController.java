package com.example.controller;

import com.example.entity.Policy;
import com.example.service.PolicyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.UrlResource;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.util.StringUtils;
import com.example.service.PolicyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import java.io.IOException;
import java.nio.file.*;


@Controller
@RequestMapping("/policies")
public class PolicyController {

    @Autowired
    private PolicyService policyService;

    @PostMapping("/save")
    public String savePolicy(@ModelAttribute("policy") Policy policy, @RequestParam("document") MultipartFile multipartFile) throws IOException {
        String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
        policy.setDocument(fileName);
        policyService.savePolicy(policy);

        String uploadDir = "policy-documents/" + policy.getId();
        Files.createDirectories(Paths.get(uploadDir));
        Path filePath = Paths.get(uploadDir).resolve(fileName);
        Files.copy(multipartFile.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

        return "redirect:/policies";
    }


    @GetMapping("/download/{id}")
    public ResponseEntity<UrlResource> downloadDocument(@PathVariable Long id) throws IOException {
        Policy policy = policyService.getPolicyById(id);
        Path filePath = Paths.get("policy-documents/" + policy.getId() + "/" + policy.getDocument());

        // Using UrlResource to create a resource from the file path
        UrlResource resource = new UrlResource(filePath.toUri());

        if (resource.exists() && resource.isReadable()) {
            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType("application/octet-stream"))
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
                    .body(resource);
        } else {
            throw new RuntimeException("Could not read the file: " + policy.getDocument());
        }
    }
    @GetMapping
    public String getAllPolicies(Model model, @RequestParam(value = "query", required = false) String query,
                                 @RequestParam(value = "page", required = false, defaultValue = "0") int page) {
        PageRequest pageable = PageRequest.of(page, 10);
        model.addAttribute("policies", policyService.searchPolicies(query, pageable));
        return "policies";
    }
}

