package com.example.implementation;


import com.example.entity.Policy;

import com.example.repository.PolicyRepository;
import com.example.service.EmailService;
import com.example.service.PolicyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.*;
import java.util.Comparator;
import java.util.List;

@Service
public class PolicyServiceImpl implements PolicyService {

    @Autowired
    private PolicyRepository policyRepository;

    @Autowired
    private EmailService emailService;

    @Override
    public Policy savePolicy(Policy policy) {
        Policy savedPolicy = policyRepository.save(policy);
        emailService.sendPolicyNotification("admin@example.com", "Policy Saved", "Policy " + policy.getPolicyNumber() + " has been saved.");
        return savedPolicy;
    }


    @Override
    public Policy getPolicyById(Long id) {
        return policyRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid policy Id:" + id));
    }

    @Override
    public List<Policy> getAllPolicies() {
        return policyRepository.findAll();
    }

    @Override
    public Page<Policy> searchPolicies(String query, Pageable pageable) {
        return policyRepository.findAll((root, criteriaQuery, criteriaBuilder) ->
                criteriaBuilder.like(root.get("policyHolderName"), "%" + query + "%"), pageable);
    }
}
